package com.foo.game.domain.bowling;

public class BowlingGameActionFactory {
	public static BowlingGameAction getBowlingGameAction(String identifier) {
		BowlingGameAction gameAction = null;
		if (Strike.IDENTIFIERS.contains(identifier)) {
			gameAction = new Strike();
		} else if (Foul.IDENTIFIERS.contains(identifier)) {
			gameAction = new Foul();
		} else if (RegularShot.IDENTIFIERS.contains(identifier)) {
			gameAction = new RegularShot(Integer.valueOf(identifier));
		}
		return gameAction;
	}
}
