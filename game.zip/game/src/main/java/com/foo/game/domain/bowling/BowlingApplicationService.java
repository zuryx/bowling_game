package com.foo.game.domain.bowling;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.foo.game.domain.Game;
import com.foo.game.domain.GameAdapter;
import com.foo.game.domain.GameRecordFormatException;
import com.foo.game.domain.GameRecordReader;
import com.foo.game.domain.GameScorePrinter;
import com.foo.game.infrastructure.FileReader;
import com.foo.game.infrastructure.FileValidator;
import com.foo.game.infrastructure.InvalidFileException;

public class BowlingApplicationService {

	private FileReader fileReader;
	private FileValidator genericFileValidator;
	private GameRecordReader<BasicBowlingGameRecord> bowlingGameRecordReader;
	private GameAdapter<BasicBowlingGameRecord, BowlingPlayerGameAction> basicBowlingGameRecordGameAdapter;
	private Game<BowlingPlayerGameAction,BowlingGameScore> bowlingGame;
	private GameScorePrinter<BowlingGameScore> printer;
	
	public BowlingApplicationService(FileReader fileReader, FileValidator genericFileValidator,
			GameRecordReader<BasicBowlingGameRecord> bowlingGameRecordReader,
			BasicBowlingGameRecordGameAdapter basicBowlingGameRecordGameAdapter, Game<BowlingPlayerGameAction,BowlingGameScore> bowlingGame,
			GameScorePrinter<BowlingGameScore> printer) {
		super();
		this.fileReader = fileReader;
		this.genericFileValidator = genericFileValidator;
		this.bowlingGameRecordReader = bowlingGameRecordReader;
		this.basicBowlingGameRecordGameAdapter = basicBowlingGameRecordGameAdapter;
		this.bowlingGame = bowlingGame;
		this.printer = printer;
	}

	public void runBowlingGame(Path filePath) {		
		try {
			List<String> gameRecords = fileReader.readFile((filePath),genericFileValidator);			
			List<BasicBowlingGameRecord> basicBowlingGameRecords = bowlingGameRecordReader.readGameRecord(gameRecords);
			List<BowlingPlayerGameAction> bowlingPlayerGameActions = new ArrayList<>();
			for (BasicBowlingGameRecord basicBowlingGameRecord : basicBowlingGameRecords) {
				bowlingPlayerGameActions.add(basicBowlingGameRecordGameAdapter.adapt(basicBowlingGameRecord));
			}
			BowlingGameScore score = bowlingGame.runGame(bowlingPlayerGameActions);
			printer.printScore(score);
		} catch (InvalidFileException | GameRecordFormatException e) {
			System.out.println(e.getMessage());
		}
	}

}
