package com.foo.game.domain.bowling;

import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.foo.game.infrastructure.ApplicationProperties;
import com.foo.game.infrastructure.FileReader;
import com.foo.game.infrastructure.GenericFileValidator;

public class BowlingAppplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(BowlingAppplication.class);

	public static void main(String[] args) throws Exception {
		if (args.length < 1) {
			System.out.println(ApplicationProperties.INSTANCE.getFileNotProvidedErrorMessage());
		}
		LOGGER.debug("Initializing BowlingApplicationService");
		BowlingGameScore bowlingGameScore = new BowlingGameScore();
		new BowlingApplicationService(new FileReader(), new GenericFileValidator(), new BowlingGameRecordReader(),
				new BasicBowlingGameRecordGameAdapter(),
				new BowlingGame(bowlingGameScore, new BowlingGameReferee(bowlingGameScore)),
				new BowlingGameScorePrinter()).runBowlingGame(Paths.get(args[0]));
	}

}