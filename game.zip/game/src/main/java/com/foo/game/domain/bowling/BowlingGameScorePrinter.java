package com.foo.game.domain.bowling;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.foo.game.domain.GameScorePrinter;
import com.foo.game.domain.Player;

public class BowlingGameScorePrinter implements GameScorePrinter<BowlingGameScore>{

	@Override
	public void printScore(BowlingGameScore bowlingGameScore) {
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>Score<<<<<<<<<<<<<<<<<<<<<<");
		printHeader();
		Map<Player<BowlingGameAction>, List<Frame>> bowlingPlayerScores = bowlingGameScore.getBowlingPlayerScores();
		
		Set<Player<BowlingGameAction>> players = bowlingPlayerScores.keySet();
		for (Player<BowlingGameAction> player : players) {
			List<Frame> frames = bowlingPlayerScores.get(player);
			System.out.println(player.getPlayerName());
			StringBuilder pinfalls = new StringBuilder();
			pinfalls.append("pinfalls\t");
			StringBuilder score = new StringBuilder();
			score.append("score\t\t");
			for (Frame frame : frames) {				
				score.append(frame.calculateScore());
				List<BowlingGameAction> bowlingGameActions = frame.getBowlingGameActions();
				boolean shot1Foul = Foul.IDENTIFIERS.contains(bowlingGameActions.get(0).getName());
				int shot1 = bowlingGameActions.get(0).getKnockDownPins();				
				if (frame.getFrameNumber() == 10) {
					boolean shot2Foul = Foul.IDENTIFIERS.contains(bowlingGameActions.get(1).getName());
					int shot2 = bowlingGameActions.get(1).getKnockDownPins();
					if (shot1 == 10) {
						boolean shot3Foul = Foul.IDENTIFIERS.contains(bowlingGameActions.get(2).getName());
						int shot3 = bowlingGameActions.get(2).getKnockDownPins();
						pinfalls.append("X").append(" ");
						if (shot2 == 10) {
							pinfalls.append("X").append(" ");
						}
						if (shot2 + shot3 == 10) {
							pinfalls.append(shot2Foul?"F":shot2).append(" ").append("/");
						} else {
							pinfalls.append(shot2Foul?"F":shot2).append(" ").append(shot3Foul?"F":shot3);
						}
					} else if (shot1+shot2 == 10) {
						int shot3 = bowlingGameActions.get(2).getKnockDownPins();
						pinfalls.append(shot1Foul?"F":shot1).append(" ").append("/");
						if (shot3 == 10) {
							pinfalls.append("X");
						}
					} else {
						pinfalls.append(shot1Foul?"F":shot1).append(" ").append(shot2Foul?"F":shot2);
					}
				} else {
					if (shot1 == 10) {
						pinfalls.append("X");
					} else {
						boolean shot2Foul = Foul.IDENTIFIERS.contains(bowlingGameActions.get(1).getName());
						int shot2 = bowlingGameActions.get(1).getKnockDownPins();
						if (shot1+shot2 == 10) {
							pinfalls.append(shot1Foul?"F":shot1).append(" ").append("/");						
						} else {
							pinfalls.append(shot1Foul?"F":shot1).append(" ").append(shot2Foul?"F":shot2);
						}
					}					
				}
				pinfalls.append("\t");
				score.append("\t");
			}
			System.out.println(pinfalls);
			System.out.println(score);
		}
	}
	
	private void printHeader() {
		StringBuilder headerBuilder = new StringBuilder();
		headerBuilder.append("Frame\t");
		for(int i = 1 ; i < 11;i++) {
			headerBuilder.append("\t").append(i);
		}
		System.out.println(headerBuilder.toString());
	}
}
