package com.foo.game.domain;

import java.util.List;

/**
 * A simple interface to read data as List<String> and create a new List<T> of domain objects
 * 
 * @author ricardo_barrera
 *
 * @param <T> type to transform each String
 */
public interface GameRecordReader<T> {
	/**
	 * Read each string and transform it into a specific domain object
	 * 
	 * @param gameRecords
	 * @return a domain object that contains all the information inside the data provided 
	 */
	public List<T> readGameRecord(List<String> gameRecords) throws GameRecordFormatException;
}
