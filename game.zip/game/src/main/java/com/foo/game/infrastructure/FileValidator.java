package com.foo.game.infrastructure;

import java.nio.file.Path;

/**
 * A simple interface to declare custom validations for a file in the file
 * system a e.g. file type, permissions, size, location, etc.
 *
 */
public interface FileValidator {

	/**
	 * Validate the file through a collection of custom validations
	 * 
	 * @param filePath the path to the file
	 * @throws InvalidFileException in case the file does not pass a custom
	 *                              validation
	 */
	public void validateFile(Path filePath) throws InvalidFileException;
}
