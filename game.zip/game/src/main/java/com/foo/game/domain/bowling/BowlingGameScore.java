package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foo.game.domain.GameScore;
import com.foo.game.domain.Player;

public class BowlingGameScore implements GameScore<BowlingPlayerScore> {
	
	private Map<Player<BowlingGameAction>,List<Frame>> bowlingPlayerScores = new HashMap<>();	
	
	@Override
	public void updateScore(BowlingPlayerScore bowlingPlayerScore) {
		final Frame refereeFrame = bowlingPlayerScore.getFrame();
		final Player<BowlingGameAction> player = bowlingPlayerScore.getPlayer();
		final BowlingGameAction bowlingGameAction = bowlingPlayerScore.getBowlingGameAction();
				
		Frame playerFrame = findPlayerFrame(refereeFrame, player);		
		
		playerFrame.addBowlingGameAction(bowlingGameAction);
	}
	
	public void addPlayer(Player<BowlingGameAction> player) {
		bowlingPlayerScores.put(player, new ArrayList<>());
	}
	
	private Frame findPlayerFrame(Frame refereeFrame,Player<BowlingGameAction> player) {
		List<Frame> frames = bowlingPlayerScores.get(player);
		boolean isNewFrame = true;
		Frame playerFrame = new Frame();
		playerFrame.setFrameNumber(refereeFrame.getFrameNumber());
		for (Frame fr : frames) {
			if (fr.getFrameNumber() == refereeFrame.getFrameNumber()) {
				isNewFrame = false;
				playerFrame = fr;
				break;
			}
		}
		if (isNewFrame) {			
			frames.add(playerFrame);
		}
		return playerFrame;
	}
	
	public void prepareScore() {
		Collection<List<Frame>> frames = bowlingPlayerScores.values();
		for (List<Frame> f : frames) {
			for(int i = 0; i < f.size() - 1;i++) {
				Frame currentFrame = f.get(i);
				Frame nextFrame = f.get(i+1);				
				currentFrame.setNextFrame(nextFrame);
				nextFrame.setPreviousFrame(currentFrame);
			}
		}		
	}
	
	public Map<Player<BowlingGameAction>, List<Frame>> getBowlingPlayerScores() {
		return bowlingPlayerScores;
	}
}
