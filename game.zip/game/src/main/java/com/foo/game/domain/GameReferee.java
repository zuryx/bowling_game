package com.foo.game.domain;

import java.util.List;

public interface GameReferee<T,S extends GameAction<?>> {
	public void checkGamePlay(T t) throws GameException;
	public void addPlayers(List<Player<S>> player);
}