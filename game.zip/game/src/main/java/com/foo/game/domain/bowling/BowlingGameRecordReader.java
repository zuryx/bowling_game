package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.foo.game.domain.GameRecordFormatException;
import com.foo.game.domain.GameRecordReader;
import com.foo.game.infrastructure.ApplicationProperties;

/**
 * Game record reader for bowling games, each string must follow the two tab-separated columns format:
 * 1st column: Alphanumeric strings and special symbols e.g. @,_,#, etc
 * 2nd column: 'F' letter or [0-10] number
 *
 * @author ricardo_barrera
 *
 * @see BasicBowlingGameRecord
 */
public class BowlingGameRecordReader implements GameRecordReader<BasicBowlingGameRecord> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BowlingGameRecordReader.class);
	
	private String recordGameFormetErrorMessage = ApplicationProperties.INSTANCE.getRecordGameFormatErrorMessage();	
	private String wrongNumberOfKnockedDownPinsErrorMessage = ApplicationProperties.INSTANCE.getRecordGameKnockedDownPinFormatErrorMessage();
	
	private Pattern pattern = Pattern.compile("^(\\S+)\\t(F|[0-9]{1,2})$");
	
	@Override
	public List<BasicBowlingGameRecord> readGameRecord(final List<String> gameRecords) throws GameRecordFormatException {
		LOGGER.info("Start reading game record");
		final List<BasicBowlingGameRecord> basicBowlingGameRecords = new ArrayList<>();
		for (int i = 0; i < gameRecords.size();i++) {
			basicBowlingGameRecords.add(processGameRecord(gameRecords.get(i),i+1));
		}
		LOGGER.info("Game record was read corretly");
		return basicBowlingGameRecords;
	}
	
	private BasicBowlingGameRecord processGameRecord(String gameRecordLine, int lineNumber) throws GameRecordFormatException {
		LOGGER.debug("Raw game record={}",gameRecordLine);
		BasicBowlingGameRecord basicBowlingGameRecord = null;
		if (isValidGameRecordLine(gameRecordLine)) {
			final String[] playerAndPinsKnockedDown = splitGameRecordLine(gameRecordLine,lineNumber);
			basicBowlingGameRecord = createBasicBowlingGameRecord(playerAndPinsKnockedDown, gameRecordLine, lineNumber);
		} else {
			LOGGER.warn("Game record \"{}\", line number = {} is invalid",gameRecordLine,lineNumber);
			throw new GameRecordFormatException(String.format(recordGameFormetErrorMessage, gameRecordLine,lineNumber));
		}
		return basicBowlingGameRecord;
	}
	
	private boolean isValidGameRecordLine(String gameRecordLine) {
		return pattern.matcher(gameRecordLine).matches();
	}
	
	private String[] splitGameRecordLine(String gameRecordLine, int lineNumber) throws GameRecordFormatException {
		LOGGER.debug("Start split process for Game Record \"{}\"",gameRecordLine);
		final String[] playerAndPinsKnockedDown = gameRecordLine.split("\\t");
		if (playerAndPinsKnockedDown.length != 2) {
			LOGGER.debug("An unexpected error occurred on the split process Game Record {}",gameRecordLine);
			LOGGER.debug("Split result for Game Record {}:{}",gameRecordLine,playerAndPinsKnockedDown);
			throw new GameRecordFormatException(String.format(recordGameFormetErrorMessage, gameRecordLine,lineNumber));
		}
		return playerAndPinsKnockedDown;
	}
	
	private BasicBowlingGameRecord createBasicBowlingGameRecord(String[] playerAndPinsKnockedDown,String gameRecordLine,int lineNumber) throws GameRecordFormatException {
		final String playerName = playerAndPinsKnockedDown[0];
		final String pinsKnockedDown = playerAndPinsKnockedDown[1];
		LOGGER.debug("Game Record \"{}\" -> player={}, knocked down pins={}",playerName,pinsKnockedDown);
		BasicBowlingGameRecord basicBowlingGameRecord;
		try {
			basicBowlingGameRecord = new BasicBowlingGameRecord(playerName,pinsKnockedDown);
		} catch (IllegalArgumentException e) {
			LOGGER.debug("An error ocurred while creating a BasicBowlingGameRecord",e);
			throw new GameRecordFormatException(String.format(wrongNumberOfKnockedDownPinsErrorMessage, gameRecordLine,lineNumber));
		}
		return basicBowlingGameRecord;
	}
}
