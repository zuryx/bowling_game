package com.foo.game.domain.bowling;

import com.foo.game.domain.GameAction;

/**
 * Marker class for bowling domain
 * 
 * @author ricardo_barrera
 *
 */
public abstract class BowlingGameAction implements GameAction<Integer> {
	public abstract int getKnockDownPins();
}
