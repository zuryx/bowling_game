package com.foo.game.domain;

public interface GameScorePrinter<T> {
	public void printScore(T t);
}
