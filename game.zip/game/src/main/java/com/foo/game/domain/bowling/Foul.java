package com.foo.game.domain.bowling;

import java.util.Arrays;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Foul extends BowlingGameAction {
	private static final Logger LOGGER = LoggerFactory.getLogger(Foul.class);
	private String name = "foul";
	public static Collection<String> IDENTIFIERS = Arrays.asList("F","foul");

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer executeAction() {
		LOGGER.debug("A {} was executed 0 pins were knock down", getName());
		return 0;
	}
	
	@Override
	public int getKnockDownPins() {
		return 0;
	}
}
