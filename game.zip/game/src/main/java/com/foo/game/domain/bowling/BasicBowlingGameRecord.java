package com.foo.game.domain.bowling;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 
 * Each line in the game record file for bowling games will be transform it in this model
 * 
 * @author ricardo_barrera
 *
 */
public class BasicBowlingGameRecord {

	private static final Logger LOGGER = LoggerFactory.getLogger(BasicBowlingGameRecord.class);

	private String player;
	private String pinsKnockedDown;

	public BasicBowlingGameRecord() {
	}

	public BasicBowlingGameRecord(String player, String pinsKnockedDown) {
		setPlayer(player);
		setPinsKnockedDown(pinsKnockedDown);
	}

	public String getPlayer() {
		return player;
	}

	public void setPlayer(final String player) {
		Objects.requireNonNull(player, "");
		LOGGER.debug("Setting player name = {}", player);
		if (player.trim().isEmpty()) {
			LOGGER.warn("Player names cannot be empty");
			throw new IllegalArgumentException("player name cannot be empty");
		}
		this.player = player;
	}

	public String getPinsKnockedDown() {
		return pinsKnockedDown;
	}

	public void setPinsKnockedDown(final String pinsKnockedDown) {
		Objects.requireNonNull(pinsKnockedDown, "knocked down pins cannot be null");
		LOGGER.debug("Setting pinsKnockedDown = {}", pinsKnockedDown);
		boolean isValid = false;
		if (pinsKnockedDown.equals("F")) {
			isValid = true;
		} else {
			try {
				int numberOfPinsKnockedDown = Integer.valueOf(pinsKnockedDown);
				if (numberOfPinsKnockedDown >= 0 && numberOfPinsKnockedDown < 11) {
					isValid = true;
				}
			} catch (NumberFormatException e) {
				isValid = false;
			}
		}
		if (!isValid) {
			LOGGER.warn("An error occurred while setting {}, knocked down pins must be [0-10] or 'F' char",
					pinsKnockedDown);
			throw new IllegalArgumentException("knocked down pins must be [0-10] or 'F' char");
		}

		this.pinsKnockedDown = pinsKnockedDown;
	}

}
