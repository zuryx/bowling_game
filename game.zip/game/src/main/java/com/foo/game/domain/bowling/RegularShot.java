package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegularShot extends BowlingGameAction {
	private static final Logger LOGGER = LoggerFactory.getLogger(RegularShot.class);
	public static Collection<String> IDENTIFIERS;
	private String name = "regular_shot";
	private int knockedDownPins;
	static {
		IDENTIFIERS = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			IDENTIFIERS.add(String.valueOf(i));
		}
	}

	public RegularShot(int knockedDownPins) {
		this.knockedDownPins = knockedDownPins;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer executeAction() {
		LOGGER.debug("A {} was executed {} pins were knock down", getName(),knockedDownPins);
		return knockedDownPins;
	}
	
	@Override
	public int getKnockDownPins() {
		return knockedDownPins;
	}
}

