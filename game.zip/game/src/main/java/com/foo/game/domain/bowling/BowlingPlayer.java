package com.foo.game.domain.bowling;

import java.util.Objects;

import com.foo.game.domain.Player;

public class BowlingPlayer implements Player<BowlingGameAction> {

	private String playerName;

	public BowlingPlayer(final String playerName) {
		this.playerName = playerName;
	}

	@Override
	public String getPlayerName() {
		return playerName;
	}

	@Override
	public void executeGameAction(BowlingGameAction gameAction) {
		gameAction.executeAction();
	}

	@Override
	public String toString() {
		return playerName;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final BowlingPlayer other = (BowlingPlayer) obj;
		return Objects.equals(this.playerName, other.playerName);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(playerName);
	}
}
