package com.foo.game.domain.bowling;

import com.foo.game.domain.Player;

public class BowlingPlayerScore {
	private Player<BowlingGameAction> player;
	private BowlingGameAction bowlingGameAction;
	private Frame frame;

	public Player<BowlingGameAction> getPlayer() {
		return player;
	}

	public void setPlayer(Player<BowlingGameAction> player) {
		this.player = player;
	}

	public Frame getFrame() {
		return frame;
	}
	
	public void setFrame(Frame frame) {
		this.frame = frame;
	}
	
	public BowlingGameAction getBowlingGameAction() {
		return bowlingGameAction;
	}
	
	public void setBowlingGameAction(BowlingGameAction bowlingGameAction) {
		this.bowlingGameAction = bowlingGameAction;
	}

}
