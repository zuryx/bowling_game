package com.foo.game.infrastructure;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A simple file reader that return the content of a file as a list of strings.
 * A File Reader can make use of a File Validator if is required to execute some
 * validations before reading the file.
 */
public class FileReader {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileReader.class);
	
	private String readError = ApplicationProperties.INSTANCE.getReadFileErrorMessage();


	/**
	 * 
	 * @param filePath      the path to the file
	 * @param fileValidator the file validator to be used before reading the file
	 * @return the lines of the file as a list of stings
	 * @see FileValidator
	 * @throws InvalidFileException
	 */
	public List<String> readFile(final Path filePath, final FileValidator fileValidator) throws InvalidFileException {		
		fileValidator.validateFile(filePath);
		return readFile(filePath);
	}

	/**
	 * 
	 * @param filePath the path to the file
	 * @return the lines of the file as a list of stings
	 * @throws InvalidFileException
	 */
	public List<String> readFile(final Path filePath) throws InvalidFileException {
		LOGGER.info("Start reading file {}.",filePath);
		List<String> lines = new ArrayList<String>();
		try {
			lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
		} catch (IOException e) {
			LOGGER.warn("An exception ocurred while reading a file", e);
			throw new InvalidFileException(String.format(readError, filePath.toString()));
		}
		LOGGER.info("File {} was read correctly",filePath);
		LOGGER.debug("Total number of lines = {} for file {}",lines.size(),filePath);
		return lines;
	}
}
