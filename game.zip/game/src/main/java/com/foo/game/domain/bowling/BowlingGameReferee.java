package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foo.game.domain.GameAction;
import com.foo.game.domain.GameException;
import com.foo.game.domain.GameReferee;
import com.foo.game.domain.Player;
import com.foo.game.infrastructure.ApplicationProperties;

public class BowlingGameReferee implements GameReferee<BowlingPlayerGameAction, BowlingGameAction> {

	private String unallowedNumberOfShots = ApplicationProperties.INSTANCE.getPlayerShotManyTimeErrorMessage();
	private String exceedNumberKnockedPins = ApplicationProperties.INSTANCE.getExceedNumberKnockedPinsErrorMessage();

	private List<Player<BowlingGameAction>> players = new ArrayList<>();
	private Map<Player<BowlingGameAction>, PlayerStatus> playerStatuses = new HashMap<>();
	private Frame currentFrame;
	private Player<BowlingGameAction> currentPlayer;
	private int maxNumberOfPinsByFrame = 10;

	private BowlingGameScore gameScore;

	public BowlingGameReferee(BowlingGameScore gameScore) {
		currentFrame = new Frame();
		currentFrame.setFrameNumber(1);
		this.gameScore = gameScore;
	}

	@Override
	public void addPlayers(List<Player<BowlingGameAction>> players) {
		this.players.addAll(players);
		for (Player<BowlingGameAction> player : players) {
			playerStatuses.put(player, new PlayerStatus());
			gameScore.addPlayer(player);
		}
		currentPlayer = this.players.get(0);
	}

	@Override
	public void checkGamePlay(BowlingPlayerGameAction t) throws GameException {
		final Player<BowlingGameAction> player = t.getPlayer();
		final GameAction<Integer> gameAction = t.getGameAction();

		if (!player.equals(currentPlayer)) {
			throw new GameException(String.format(unallowedNumberOfShots, player));
		}

		PlayerStatus playerStatus = playerStatuses.get(currentPlayer);
		if (playerStatus.finish) {
			// TODO throw finish exception
			throw new GameException(String.format(unallowedNumberOfShots, player));
		}
		updateGameScore((BowlingGameAction) gameAction);
		if (gameAction instanceof Strike) {
			if (isLastFrame()) {
				if (playerStatus.isRunningExtraShots()) {
					if (playerStatus.haveExtraShotsAvailable()) {
						playerStatus.removeExtraShot();
						if (!playerStatus.haveExtraShotsAvailable()) {
							playerStatus.stopPlaying();
							currentPlayer = getNextPlayer(player);
						}
					}
				} else {
					playerStatus.addKnockOutPins(((Strike) gameAction).getKnockDownPins());
					if (playerStatus.getKnockedOutPins() > maxNumberOfPinsByFrame) {
						throw new GameException(String.format(exceedNumberKnockedPins, player, maxNumberOfPinsByFrame,
								playerStatus.getKnockedOutPins()));
					}
					if (playerStatus.getShots() == 0) {
						playerStatus.activeExtraShots(2);
					} else {
						playerStatus.activeExtraShots(1);
					}
					playerStatus.resetKnockedOutPinsAndShots();
				}
			} else {
				playerStatus.addKnockOutPins(((Strike) gameAction).getKnockDownPins());
				int totalKnockedOutPins = playerStatus.getKnockedOutPins();
				if (totalKnockedOutPins > maxNumberOfPinsByFrame) {
					throw new GameException(String.format(exceedNumberKnockedPins, player, maxNumberOfPinsByFrame,
							totalKnockedOutPins));
				}
				currentPlayer = getNextPlayer(player);
				playerStatus.resetKnockedOutPinsAndShots();
			}
		} else if (gameAction instanceof Foul) {
			if (isLastFrame()) {
				if (playerStatus.isRunningExtraShots()) {
					if (playerStatus.haveExtraShotsAvailable()) {
						playerStatus.removeExtraShot();
						if (!playerStatus.haveExtraShotsAvailable()) {
							playerStatus.stopPlaying();
							currentPlayer = getNextPlayer(player);
						}
					}
				} else {
					if (getShotsByPlayer(player) >= 1) {
						currentPlayer = getNextPlayer(player);
						playerStatus.resetKnockedOutPinsAndShots();
						playerStatus.stopPlaying();
					} else {
						addShotToPlayer(player);
					}
				}
			} else {
				if (getShotsByPlayer(player) >= 1) {
					currentPlayer = getNextPlayer(player);
					playerStatus.resetKnockedOutPinsAndShots();
				} else {
					addShotToPlayer(player);
				}
			}
		} else if (gameAction instanceof RegularShot) {
			if (isLastFrame()) {
				if (playerStatus.isRunningExtraShots()) {
					if (playerStatus.haveExtraShotsAvailable()) {
						playerStatus.removeExtraShot();
						if (!playerStatus.haveExtraShotsAvailable()) {
							playerStatus.stopPlaying();
							currentPlayer = getNextPlayer(player);
						}
					}
				} else {
					playerStatus.addKnockOutPins(((RegularShot) gameAction).getKnockDownPins());
					int totalKnockedOutPins = playerStatus.getKnockedOutPins();
					if (totalKnockedOutPins > maxNumberOfPinsByFrame) {
						throw new GameException(String.format(exceedNumberKnockedPins, player, maxNumberOfPinsByFrame,
								totalKnockedOutPins));
					}
					if (totalKnockedOutPins == maxNumberOfPinsByFrame) {
						playerStatus.activeExtraShots(1);
						playerStatus.resetKnockedOutPinsAndShots();
					} else {
						if (getShotsByPlayer(player) >= 1) {
							currentPlayer = getNextPlayer(player);
							playerStatus.resetKnockedOutPinsAndShots();
							playerStatus.stopPlaying();
							
						} else {
							addShotToPlayer(player);
						}
					}
				}
			} else {
				playerStatus.addKnockOutPins(((RegularShot) gameAction).getKnockDownPins());
				int totalKnockedOutPins = playerStatus.getKnockedOutPins();
				if (totalKnockedOutPins > maxNumberOfPinsByFrame) {
					throw new GameException(String.format(exceedNumberKnockedPins, player, maxNumberOfPinsByFrame,
							totalKnockedOutPins));
				}
				if (getShotsByPlayer(player) >= 1) {
					currentPlayer = getNextPlayer(player);
					playerStatus.resetKnockedOutPinsAndShots();
				} else {
					addShotToPlayer(player);
				}
			}
		}
	}

	private Player<BowlingGameAction> getNextPlayer(Player<BowlingGameAction> player) {
		int size = players.size();
		int currentIndex = players.indexOf(player);
		int nextIndex = 0;
		if (currentIndex < size - 1) {
			nextIndex++;
		} else {
			createNextFrame();
		}
		return players.get(nextIndex);
	}

	public int getShotsByPlayer(Player<BowlingGameAction> player) {
		return playerStatuses.get(player).getShots();
	}

	public void addShotToPlayer(Player<BowlingGameAction> player) {
		playerStatuses.get(player).addShot();
	}

	public Frame getCurrentFrame() {
		return currentFrame;
	}

	private void createNextFrame() {
		int frameNumber = currentFrame.getFrameNumber();
		if (!isLastFrame()) {
			currentFrame = new Frame();
			currentFrame.setFrameNumber(frameNumber + 1);
		}
	}

	private boolean isLastFrame() {
		return currentFrame.getFrameNumber() == 10;
	}

	public boolean isGameFinish() {
		Collection<PlayerStatus> playerStatus = playerStatuses.values();
		return playerStatus.stream().filter(e -> e.finish).count() == playerStatus.size();
	}

	private void updateGameScore(BowlingGameAction gameAction) {
		BowlingPlayerScore bowlingPlayerScore = new BowlingPlayerScore();
		bowlingPlayerScore.setFrame(currentFrame);
		bowlingPlayerScore.setPlayer(currentPlayer);
		bowlingPlayerScore.setBowlingGameAction(gameAction);
		gameScore.updateScore(bowlingPlayerScore);
	}

	private class PlayerStatus {
		int shots = 0;
		int knockOutPins = 0;
		boolean finish = false;
		int extraShots = 0;
		boolean isRunningExtraShots = false;

		public void addKnockOutPins(int pins) {
			knockOutPins += pins;
		}

		public int getKnockedOutPins() {
			return knockOutPins;
		}

		public void resetKnockedOutPinsAndShots() {
			shots = 0;
			knockOutPins = 0;
		}

		public int getShots() {
			return shots;
		}

		public void addShot() {
			shots++;
		}

		public void activeExtraShots(int extraShots) {
			this.extraShots = extraShots;
			isRunningExtraShots = true;
		}

		public boolean isRunningExtraShots() {
			return isRunningExtraShots;
		}

		public boolean haveExtraShotsAvailable() {
			return extraShots > 0;
		}

		public void removeExtraShot() {
			extraShots--;
		}

		public void stopPlaying() {
			finish = true;
		}
	}

}
