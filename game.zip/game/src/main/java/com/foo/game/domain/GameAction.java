package com.foo.game.domain;

public interface GameAction<T> {
	public String getName();
	public T executeAction();
}
