package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Frame {
	private int frameNumber;
	private List<BowlingGameAction> bowlingGameActions = new ArrayList<>();
	private Frame nextFrame;
	private Frame previousFrame;
	
	public int getFrameNumber() {
		return frameNumber;
	}

	public void setFrameNumber(int frameNumber) {
		this.frameNumber = frameNumber;
	}
	
	public Frame getPreviousFrame() {
		return previousFrame;
	}
	
	public void setPreviousFrame(Frame previousFrame) {
		this.previousFrame = previousFrame;
	}

	public List<BowlingGameAction> getBowlingGameActions() {
		return bowlingGameActions;
	}

	public void addBowlingGameAction(BowlingGameAction bowlingGameAction) {
		bowlingGameActions.add(bowlingGameAction);
	}
	
	public Frame getNextFrame() {
		return nextFrame;
	}
	
	public void setNextFrame(Frame nextFrame) {
		this.nextFrame = nextFrame;
	}
	
	public int calculateScore() {		
		int score = 0;
		int prevScore = 0;
		int nextScore = 0;

		if (isSpare()) {
			nextScore = calculateScoreForSpare();
		}
		if (isStrike()) {
			nextScore = calculateScoreForStrike();
		}
		
		if (previousFrame!=null) {
			prevScore = previousFrame.calculateScore();
		}		
		
		for (BowlingGameAction bowlingGameAction : bowlingGameActions) {
			score += bowlingGameAction.getKnockDownPins();
		}
		
		return prevScore+score+nextScore;
	}
	
	private int calculateScoreForSpare() {
		int score = 0;
		if (nextFrame != null) {
			if (nextFrame.isStrike()) {
				score = 10;
			} else {
				score = nextFrame.getBowlingGameActions().get(0).getKnockDownPins();
			}
		} else if (isLastFrame()) {
			score = getBowlingGameActions().get(0).getKnockDownPins();
		}
		return score;
	}
	
	private int calculateScoreForStrike() {
		int score = 0;
		if (nextFrame != null) {
			if (nextFrame.isStrike()) {
				score = 10;
				Frame nextFrame2 = nextFrame.getNextFrame();
				if(nextFrame2 != null) {
					if (nextFrame2.isStrike()) {
						score+=10;
					} else {
						score += nextFrame2.getBowlingGameActions().get(0).getKnockDownPins();
					}
				} else if (nextFrame.isLastFrame()) {
					score+=nextFrame.getBowlingGameActions().get(1).getKnockDownPins();
				}
			} else {
				score = nextFrame.getBowlingGameActions().get(0).getKnockDownPins()+nextFrame.getBowlingGameActions().get(1).getKnockDownPins();
			}
		} else if (isLastFrame()) {
			if (!isStrike()) {
				score = getBowlingGameActions().get(0).getKnockDownPins()+getBowlingGameActions().get(1).getKnockDownPins();				
			}
		}
		return score;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Frame other = (Frame) obj;
		return Objects.equals(this.frameNumber, other.frameNumber);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(frameNumber);
	}

	public boolean isSpare() {		
		if (bowlingGameActions.get(0).getKnockDownPins()==10) {
			return false;
		}
		int score = 0;
		for (BowlingGameAction bowlingGameAction : bowlingGameActions) {
			score += bowlingGameAction.getKnockDownPins();
		}
		if (score == 10) {
			return true;
		} else {
			return false;
		}
		
	}
	
	public boolean isStrike() {
		return bowlingGameActions.get(0).getKnockDownPins()==10;
	}
	
	public boolean isLastFrame() {
		return frameNumber == 10;
	}
}
