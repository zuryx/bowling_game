package com.foo.game.domain.bowling;

import com.foo.game.domain.GameAdapter;
import com.foo.game.domain.Player;

public class BasicBowlingGameRecordGameAdapter implements GameAdapter<BasicBowlingGameRecord, BowlingPlayerGameAction> {
	@Override
	public BowlingPlayerGameAction adapt(final BasicBowlingGameRecord basicBowlingGameRecord) {
		final Player<BowlingGameAction> player = new BowlingPlayer(basicBowlingGameRecord.getPlayer());
		final BowlingGameAction bowlingGameAction = BowlingGameActionFactory.getBowlingGameAction(basicBowlingGameRecord.getPinsKnockedDown());
		return new BowlingPlayerGameAction(player, bowlingGameAction);
	}
}
