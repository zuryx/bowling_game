package com.foo.game.domain.bowling;

import com.foo.game.domain.GameAction;
import com.foo.game.domain.Player;
import com.foo.game.domain.PlayerGameAction;

public class BowlingPlayerGameAction implements PlayerGameAction<BowlingGameAction,Integer> {
	
	private Player<BowlingGameAction> player;
	private BowlingGameAction gameAction;
	
	public BowlingPlayerGameAction(Player<BowlingGameAction> player, BowlingGameAction gameAction) {
		super();
		this.player = player;
		this.gameAction = gameAction;
	}

	@Override
	public Player<BowlingGameAction> getPlayer() {
		return player;
	}
	
	@Override
	public GameAction<Integer> getGameAction() {
		return gameAction;
	}
	
	@Override
	public void executeGameAction() {
		player.executeGameAction(gameAction);		
	}
	
	@Override
	public String toString() {
		return "Player = "+player.getPlayerName()+", game action = "+gameAction.getName();		
	}
}
