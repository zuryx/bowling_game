package com.foo.game.domain.bowling;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.foo.game.domain.Game;
import com.foo.game.domain.GameException;
import com.foo.game.domain.Player;

public class BowlingGame implements Game<BowlingPlayerGameAction,BowlingGameScore> {

	private static final Logger LOGGER = LoggerFactory.getLogger(BowlingGame.class);
	
	private BowlingGameScore bowlingPlayerScore;
	
	private BowlingGameReferee bowlingGameReferee;

	public BowlingGame(BowlingGameScore bowlingPlayerScore,BowlingGameReferee bowlingGameReferee) {
		this.bowlingGameReferee = bowlingGameReferee;
		this.bowlingPlayerScore = bowlingPlayerScore;
	}
	
	@Override
	public BowlingGameScore runGame(List<BowlingPlayerGameAction> playerGameActions) {
		LOGGER.info("Bowling game will start");
		bowlingGameReferee.addPlayers(getPlayers(playerGameActions));
		for (int i = 0;i<playerGameActions.size();i++) {
			final BowlingPlayerGameAction bowlingPlayerGameAction = playerGameActions.get(i);
			try {
				bowlingGameReferee.checkGamePlay(bowlingPlayerGameAction);
			} catch (GameException e) {
				System.out.println("Error on line:"+(i+1)+" detail:"+e.getMessage());
			}
			bowlingPlayerGameAction.executeGameAction();
		}
		bowlingPlayerScore.prepareScore();
		LOGGER.info("Bowling game finished");
		return bowlingPlayerScore;
	}
	
	private List<Player<BowlingGameAction>> getPlayers(List<BowlingPlayerGameAction> playerGameActions) {
		return playerGameActions.stream().map(BowlingPlayerGameAction::getPlayer).distinct().collect(Collectors.toList());
	}
	

}
