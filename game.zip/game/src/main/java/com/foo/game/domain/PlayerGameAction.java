package com.foo.game.domain;

public interface PlayerGameAction<T extends GameAction<S>,S> {
	public Player<T> getPlayer();
	public GameAction<S> getGameAction();
	public void executeGameAction();
}
