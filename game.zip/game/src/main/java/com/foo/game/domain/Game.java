package com.foo.game.domain;

import java.util.List;

public interface Game<T,S extends GameScore<?>>{
	public S runGame(List<T> playerGameActions);	
}
