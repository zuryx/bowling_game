package com.foo.game.domain.bowling;

import java.util.Arrays;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Strike extends BowlingGameAction {
	private static final Logger LOGGER = LoggerFactory.getLogger(Strike.class);
	
	private String name = "strike";
	public static Collection<String> IDENTIFIERS = Arrays.asList("10","X");	

	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public Integer executeAction() {
		LOGGER.debug("A {} was executed 10 pins were knock down",getName());
		return 10;
	}
	
	@Override
	public int getKnockDownPins() {
		return 10;
	}

}
