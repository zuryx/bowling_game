package com.foo.game.domain;

/**
 * Thrown to indicate that a game record line has an invalid format
 * 
 * @author ricardo_barrera
 *
 */
public class GameRecordFormatException extends Exception {
	
	private static final long serialVersionUID = 1210721279908507764L;

	public GameRecordFormatException(String message) {
		super(message);
	}
}
