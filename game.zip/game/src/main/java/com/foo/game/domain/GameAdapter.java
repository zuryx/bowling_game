package com.foo.game.domain;

public interface GameAdapter <T,S> {
	public S adapt(T t);
}
