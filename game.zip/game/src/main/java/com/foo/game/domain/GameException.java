package com.foo.game.domain;

public class GameException extends Exception {

	private static final long serialVersionUID = 8662004336835714356L;

	public GameException(String message) {
		super(message);
	}
}
