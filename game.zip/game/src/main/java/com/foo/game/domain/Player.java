package com.foo.game.domain;

public interface Player<T extends GameAction<?>> {
	public String getPlayerName();
	public void executeGameAction(T gameAction);
}
