package com.foo.game.domain;

public interface GameScore<T> {
	public void updateScore(T t);
}
