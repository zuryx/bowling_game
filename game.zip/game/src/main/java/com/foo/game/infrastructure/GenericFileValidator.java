package com.foo.game.infrastructure;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericFileValidator implements FileValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(GenericFileValidator.class);
	
	private String fileNotFoundErrorMessage = ApplicationProperties.INSTANCE.getFileNotFoundErrorMessage();
	private String directoryInsteadOfFileErrorMessage = ApplicationProperties.INSTANCE.getDirectoryFoundInsteadOfFileErrorMessage();
	private String fileIsNotReadableErrorMessage = ApplicationProperties.INSTANCE.getErrorFileIsNotReadableErrorMessage();

	/**
	 * 
	 * @param filePath the path to the file
	 * @throws InvalidFileException if the file does not exist or of the file is a
	 *                              directory or if the file does not have read
	 *                              permission
	 */
	@Override
	public void validateFile(final Path filePath) throws InvalidFileException {
		Objects.requireNonNull(filePath, "file path must not be null");
		LOGGER.info("Start validation process for file {}",filePath.toString());
		validateIfTheFileExist(filePath);
		validateIfTheFileIsNotADirectory(filePath);
		validateIfTheFileIsReadable(filePath);
		LOGGER.info("File {} is valid",filePath.toString());
	}

	private void validateIfTheFileExist(final Path filePath) throws InvalidFileException {
		LOGGER.debug("Validate if file {} exists",filePath);
		if (!Files.exists(filePath)) {
			LOGGER.warn("Validation fails: File {} does not exist",filePath);
			throw new InvalidFileException(String.format(fileNotFoundErrorMessage, filePath.toString()));
		}
		LOGGER.debug("Validate if file {} exists:{}",filePath,true);
	}

	private void validateIfTheFileIsNotADirectory(final Path filePath) throws InvalidFileException {
		LOGGER.debug("Validate if file {} is not a directory",filePath);
		if (Files.isDirectory(filePath)) {
			LOGGER.warn("Validation fails: File {} is a directory",filePath);
			throw new InvalidFileException(String.format(directoryInsteadOfFileErrorMessage, filePath.toString()));
		}
		LOGGER.debug("Validate if file {} is not a directory:{}",filePath,true);
	}

	private void validateIfTheFileIsReadable(final Path filePath) throws InvalidFileException {
		LOGGER.debug("Validate if file {} has read permissions",filePath);
		if (!Files.isReadable(filePath)) {
			LOGGER.warn("Validation fails: File {} cannot be read",filePath);
			throw new InvalidFileException(String.format(fileIsNotReadableErrorMessage, filePath.toString()));
		}
		LOGGER.debug("Validate if file {} has read permissions:{}",filePath,true);
	}

}
