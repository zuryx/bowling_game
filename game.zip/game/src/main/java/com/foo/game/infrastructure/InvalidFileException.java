package com.foo.game.infrastructure;

/**
 * 
 * Exception that is intended to act as a domain wrapper to hide the complexity
 * behind the IO/NIO API
 * 
 * @author ricardo_barrera
 */
public class InvalidFileException extends Exception {

	private static final long serialVersionUID = 8708239864569910581L;

	public InvalidFileException(String message) {
		super(message);
	}

}