package com.foo.game.infrastructure;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum ApplicationProperties {
    INSTANCE;

    private final Properties properties;
    private final Logger LOGGER = LoggerFactory.getLogger(ApplicationProperties.class);
    
    ApplicationProperties() {
        properties = new Properties();
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("application.properties"));
        } catch (IOException e) {
        	LOGGER.warn("Somethin went wrong while reading properites", e);            
        }
    }

    public String getAppName() {
        return properties.getProperty("app.name");
    }
    
    public String getReadFileErrorMessage () {
    	return properties.getProperty("error.read.file");
    }
    
    public String getFileNotFoundErrorMessage () {
    	return properties.getProperty("error.file.not.found");
    }
    
    public String getDirectoryFoundInsteadOfFileErrorMessage () {
    	return properties.getProperty("error.directory.found.instead.of.file");
    }
    
    public String getErrorFileIsNotReadableErrorMessage () {
    	return properties.getProperty("error.file.is.not.readable");
    }

    public String getPlayerShotManyTimeErrorMessage () {
    	return properties.getProperty("error.player.shot.many.time");
    }
    
    public String getExceedNumberKnockedPinsErrorMessage () {
    	return properties.getProperty("error.exceed.number.knocked.pins");
    }
    
    public String getRecordGameFormatErrorMessage () {
    	return properties.getProperty("error.record.game.format");
    }
    
    public String getRecordGameKnockedDownPinFormatErrorMessage () {
    	return properties.getProperty("error.record.game.knocked.down.pins");
    }
    
    public String getFileNotProvidedErrorMessage () {
    	return properties.getProperty("error.file.not.provided");
    }
    
    
}

