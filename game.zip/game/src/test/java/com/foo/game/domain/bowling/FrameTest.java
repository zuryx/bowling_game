package com.foo.game.domain.bowling;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class FrameTest {

	@Test
	public void givenTwoRegularShotsThenAddThemUpAndIgnoreNextFrame(){
		Frame frame1 = new Frame();
		frame1.addBowlingGameAction(new RegularShot(3));
		frame1.addBowlingGameAction(new RegularShot(5));
		
		Frame frame2 = new Frame();
		frame2.addBowlingGameAction(new RegularShot(3));
		frame2.addBowlingGameAction(new RegularShot(5));
		
		frame1.setNextFrame(frame2);
		frame2.setPreviousFrame(frame1);
		
		int score = frame1.calculateScore();
		int score2 = frame2.calculateScore();
		
		Assertions.assertEquals(8,score);
		Assertions.assertEquals(16,score2);
	}
	
	@Test
	public void givenFirstFrameIsASpareWhenCalculateScoreForSecondFrameThenTakeFirstShot(){
		Frame frame1 = new Frame();
		frame1.addBowlingGameAction(new RegularShot(3));
		frame1.addBowlingGameAction(new RegularShot(7));
		
		Frame frame2 = new Frame();
		frame2.addBowlingGameAction(new RegularShot(3));
		frame2.addBowlingGameAction(new RegularShot(5));
		
		frame1.setNextFrame(frame2);
		frame2.setPreviousFrame(frame1);
		
		int score = frame1.calculateScore();
		int score2 = frame2.calculateScore();
		
		Assertions.assertEquals(13,score);
		Assertions.assertEquals(21,score2);
	}
	
	@Test
	public void givenFirstFrameIsAStrikeWhenCalculateScoreForSecondFrameThenTakeFirstShot(){
		Frame frame1 = new Frame();
		frame1.addBowlingGameAction(new RegularShot(8));
		frame1.addBowlingGameAction(new RegularShot(2));
		frame1.setFrameNumber(1);
		
		Frame frame2 = new Frame();
		frame2.addBowlingGameAction(new RegularShot(7));
		frame2.addBowlingGameAction(new RegularShot(3));
		frame2.setFrameNumber(2);
		
		Frame frame3 = new Frame();
		frame3.addBowlingGameAction(new RegularShot(3));
		frame3.addBowlingGameAction(new RegularShot(4));
		frame3.setFrameNumber(3);
		
		Frame frame4 = new Frame();
		frame4.addBowlingGameAction(new Strike());
		frame4.setFrameNumber(4);
		
		Frame frame5 = new Frame();
		frame5.addBowlingGameAction(new RegularShot(2));
		frame5.addBowlingGameAction(new RegularShot(8));
		frame5.setFrameNumber(5);
			
		Frame frame6 = new Frame();
		frame6.addBowlingGameAction(new Strike());
		frame6.setFrameNumber(6);
		
		Frame frame7 = new Frame();
		frame7.addBowlingGameAction(new Strike());
		frame7.setFrameNumber(7);
		
		Frame frame8 = new Frame();
		frame8.addBowlingGameAction(new RegularShot(8));
		frame8.addBowlingGameAction(new Foul());
		frame8.setFrameNumber(8);
		
		Frame frame9 = new Frame();
		frame9.addBowlingGameAction(new Strike());
		frame9.setFrameNumber(9);
		
		Frame frame10 = new Frame();
		frame10.addBowlingGameAction(new RegularShot(8));
		frame10.addBowlingGameAction(new RegularShot(2));
		frame10.addBowlingGameAction(new RegularShot(9));
		frame10.setFrameNumber(10);
			
		frame1.setNextFrame(frame2);
		
		frame2.setPreviousFrame(frame1);
		frame2.setNextFrame(frame3);		
		
		frame3.setPreviousFrame(frame2);
		frame3.setNextFrame(frame4);
		
		frame4.setPreviousFrame(frame3);
		frame4.setNextFrame(frame5);
		
		frame5.setPreviousFrame(frame4);
		frame5.setNextFrame(frame6);
		
		frame6.setPreviousFrame(frame5);
		frame6.setNextFrame(frame7);
		
		frame7.setPreviousFrame(frame6);
		frame7.setNextFrame(frame8);
		
		frame8.setPreviousFrame(frame7);
		frame8.setNextFrame(frame9);
		
		frame9.setPreviousFrame(frame8);
		frame9.setNextFrame(frame10);
		
		frame10.setPreviousFrame(frame9);
			
		int score = frame1.calculateScore();
		int score2 = frame2.calculateScore();
		int score3 = frame3.calculateScore();
		int score4 = frame4.calculateScore();
		int score5 = frame5.calculateScore();
		int score6 = frame6.calculateScore();
		int score7 = frame7.calculateScore();
		int score8 = frame8.calculateScore();
		int score9 = frame9.calculateScore();
		int score10 = frame10.calculateScore();
		
		Assertions.assertEquals(17,score);
		Assertions.assertEquals(30,score2);
		Assertions.assertEquals(37,score3);
		Assertions.assertEquals(57,score4);
		Assertions.assertEquals(77,score5);
		Assertions.assertEquals(105,score6);
		Assertions.assertEquals(123,score7);
		Assertions.assertEquals(131,score8);
		Assertions.assertEquals(151,score9);
		Assertions.assertEquals(170,score10);
		
	}
	
	@Test
	public void whenPerfectGameThenScoreEqualsTo300() {		
		Frame frame1 = new Frame();
		frame1.addBowlingGameAction(new Strike());
		frame1.setFrameNumber(1);
		
		Frame frame2 = new Frame();
		frame2.addBowlingGameAction(new Strike());
		frame2.setFrameNumber(2);
		
		Frame frame3 = new Frame();
		frame3.addBowlingGameAction(new Strike());
		frame3.setFrameNumber(3);
		
		Frame frame4 = new Frame();
		frame4.addBowlingGameAction(new Strike());
		frame4.setFrameNumber(4);
		
		Frame frame5 = new Frame();
		frame5.addBowlingGameAction(new Strike());
		frame5.setFrameNumber(5);
			
		Frame frame6 = new Frame();
		frame6.addBowlingGameAction(new Strike());
		frame6.setFrameNumber(6);
		
		Frame frame7 = new Frame();
		frame7.addBowlingGameAction(new Strike());
		frame7.setFrameNumber(7);
		
		Frame frame8 = new Frame();
		frame8.addBowlingGameAction(new Strike());
		frame8.setFrameNumber(8);
		
		Frame frame9 = new Frame();
		frame9.addBowlingGameAction(new Strike());
		frame9.setFrameNumber(9);
		
		Frame frame10 = new Frame();
		frame10.addBowlingGameAction(new Strike());
		frame10.addBowlingGameAction(new Strike());
		frame10.addBowlingGameAction(new Strike());
		frame10.setFrameNumber(10);
			
		frame1.setNextFrame(frame2);
		
		frame2.setPreviousFrame(frame1);
		frame2.setNextFrame(frame3);		
		
		frame3.setPreviousFrame(frame2);
		frame3.setNextFrame(frame4);
		
		frame4.setPreviousFrame(frame3);
		frame4.setNextFrame(frame5);
		
		frame5.setPreviousFrame(frame4);
		frame5.setNextFrame(frame6);
		
		frame6.setPreviousFrame(frame5);
		frame6.setNextFrame(frame7);
		
		frame7.setPreviousFrame(frame6);
		frame7.setNextFrame(frame8);
		
		frame8.setPreviousFrame(frame7);
		frame8.setNextFrame(frame9);
		
		frame9.setPreviousFrame(frame8);
		frame9.setNextFrame(frame10);
		
		frame10.setPreviousFrame(frame9);
			
		int score = frame1.calculateScore();
		int score2 = frame2.calculateScore();
		int score3 = frame3.calculateScore();
		int score4 = frame4.calculateScore();
		int score5 = frame5.calculateScore();
		int score6 = frame6.calculateScore();
		int score7 = frame7.calculateScore();
		int score8 = frame8.calculateScore();
		int score9 = frame9.calculateScore();
		int score10 = frame10.calculateScore();
		
		Assertions.assertEquals(30,score);
		Assertions.assertEquals(60,score2);
		Assertions.assertEquals(90,score3);
		Assertions.assertEquals(120,score4);
		Assertions.assertEquals(150,score5);
		Assertions.assertEquals(180,score6);
		Assertions.assertEquals(210,score7);
		Assertions.assertEquals(240,score8);
		Assertions.assertEquals(270,score9);
		Assertions.assertEquals(300,score10);
	}
	
	@Test
	public void whenOnlyFoulThenScoreEqualsToZero() {		
		Frame frame1 = new Frame();
		frame1.addBowlingGameAction(new Foul());
		frame1.addBowlingGameAction(new Foul());
		frame1.setFrameNumber(1);
		
		Frame frame2 = new Frame();
		frame2.addBowlingGameAction(new Foul());
		frame2.addBowlingGameAction(new Foul());
		frame2.setFrameNumber(2);
		
		Frame frame3 = new Frame();
		frame3.addBowlingGameAction(new Foul());
		frame3.addBowlingGameAction(new Foul());
		frame3.setFrameNumber(3);
		
		Frame frame4 = new Frame();
		frame4.addBowlingGameAction(new Foul());
		frame4.addBowlingGameAction(new Foul());
		frame4.setFrameNumber(4);
		
		Frame frame5 = new Frame();
		frame5.addBowlingGameAction(new Foul());
		frame5.addBowlingGameAction(new Foul());
		frame5.setFrameNumber(5);
			
		Frame frame6 = new Frame();
		frame6.addBowlingGameAction(new Foul());
		frame6.addBowlingGameAction(new Foul());
		frame6.setFrameNumber(6);
		
		Frame frame7 = new Frame();
		frame7.addBowlingGameAction(new Foul());
		frame7.addBowlingGameAction(new Foul());
		frame7.setFrameNumber(7);
		
		Frame frame8 = new Frame();
		frame8.addBowlingGameAction(new Foul());
		frame8.addBowlingGameAction(new Foul());
		frame8.setFrameNumber(8);
		
		Frame frame9 = new Frame();
		frame9.addBowlingGameAction(new Foul());
		frame9.addBowlingGameAction(new Foul());
		frame9.setFrameNumber(9);
		
		Frame frame10 = new Frame();
		frame10.addBowlingGameAction(new Foul());
		frame10.addBowlingGameAction(new Foul());
		frame10.setFrameNumber(10);
			
		frame1.setNextFrame(frame2);
		
		frame2.setPreviousFrame(frame1);
		frame2.setNextFrame(frame3);		
		
		frame3.setPreviousFrame(frame2);
		frame3.setNextFrame(frame4);
		
		frame4.setPreviousFrame(frame3);
		frame4.setNextFrame(frame5);
		
		frame5.setPreviousFrame(frame4);
		frame5.setNextFrame(frame6);
		
		frame6.setPreviousFrame(frame5);
		frame6.setNextFrame(frame7);
		
		frame7.setPreviousFrame(frame6);
		frame7.setNextFrame(frame8);
		
		frame8.setPreviousFrame(frame7);
		frame8.setNextFrame(frame9);
		
		frame9.setPreviousFrame(frame8);
		frame9.setNextFrame(frame10);
		
		frame10.setPreviousFrame(frame9);
			
		int score = frame1.calculateScore();
		int score2 = frame2.calculateScore();
		int score3 = frame3.calculateScore();
		int score4 = frame4.calculateScore();
		int score5 = frame5.calculateScore();
		int score6 = frame6.calculateScore();
		int score7 = frame7.calculateScore();
		int score8 = frame8.calculateScore();
		int score9 = frame9.calculateScore();
		int score10 = frame10.calculateScore();
		
		Assertions.assertEquals(0,score);
		Assertions.assertEquals(0,score2);
		Assertions.assertEquals(0,score3);
		Assertions.assertEquals(0,score4);
		Assertions.assertEquals(0,score5);
		Assertions.assertEquals(0,score6);
		Assertions.assertEquals(0,score7);
		Assertions.assertEquals(0,score8);
		Assertions.assertEquals(0,score9);
		Assertions.assertEquals(0,score10);
	}
}
