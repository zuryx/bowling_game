package com.foo.game.infrastructure;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

public class GenericFileValidatorTest {
	
	private GenericFileValidator fileValidator = new GenericFileValidator();

	@Test
	public void givenFileDoesNotExistWhenFileIsValidatedThenThrowInvalidFileException() {
		final Path filePath = Paths.get("src", "test", "resources", "file_validator", "generic_file_validator",
				"bar.txt");

		final InvalidFileException invalidFileException = Assertions.assertThrows(InvalidFileException.class, () -> {
			fileValidator.validateFile(filePath);
		});

		Assertions.assertEquals(
				"File \"src" + File.separator + "test" + File.separator + "resources" + File.separator
						+ "file_validator" + File.separator + "generic_file_validator" + File.separator
						+ "bar.txt\" does not exist, please provide an existing text file",
				invalidFileException.getMessage());
	}

	@Test
	public void givenADirectoryIsProvidedInsteadOfARegularFileWhenFileIsValidatedThenThrowInvalidFileException()
			throws FileNotFoundException {
		final Path filePath = Paths.get("src", "test", "resources", "file_validator", "generic_file_validator",
				"empty_dir");

		final InvalidFileException invalidFileException = Assertions.assertThrows(InvalidFileException.class, () -> {
			fileValidator.validateFile(filePath);
		});

		Assertions.assertEquals(
				"\"src" + File.separator + "test" + File.separator + "resources" + File.separator + "file_validator"
						+ File.separator + "generic_file_validator" + File.separator
						+ "empty_dir\" is a directory, please provide an existing text file",
				invalidFileException.getMessage());
	}

	@Test
	@EnabledOnOs({ OS.LINUX, OS.MAC })
	public void givenAFileWithoutReadPermissionIsProvidedWhenFileIsValidatedThenThrowInvalidFileException()
			throws IOException {
		final Path filePath = Paths.get("src", "test", "resources", "file_validator", "generic_file_validator",
				"exclude_files", "write_only_file.txt");
		final Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("-w--w--w-");
		final FileAttribute<Set<PosixFilePermission>> fileAttributes = PosixFilePermissions
				.asFileAttribute(permissions);
		Files.deleteIfExists(filePath);
		Files.createFile(filePath, fileAttributes);

		final InvalidFileException invalidFileException = Assertions.assertThrows(InvalidFileException.class, () -> {
			fileValidator.validateFile(filePath);
		});

		Assertions.assertEquals("File \"src" + File.separator + "test" + File.separator + "resources" + File.separator
				+ "file_validator" + File.separator + "generic_file_validator" + File.separator + "exclude_files"
				+ File.separator + "write_only_file.txt\" is not readable, please check its permissions",
				invalidFileException.getMessage());
	}

	@Test
	public void givenAValidFileIsProvidedWhenFileIsValidatedThenNoExceptionIsThrown()
			throws FileNotFoundException, InvalidFileException {
		final Path filePath = Paths.get("src", "test", "resources", "file_validator", "generic_file_validator",
				"game_record.txt");

		fileValidator.validateFile(filePath);
	}

}
