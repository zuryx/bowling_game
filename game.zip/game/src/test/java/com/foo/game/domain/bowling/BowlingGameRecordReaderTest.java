package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.foo.game.domain.GameRecordFormatException;

public class BowlingGameRecordReaderTest {
	
	private BowlingGameRecordReader bowlingGameRecordReader;

	@BeforeEach
	public void beforeTest() {
		bowlingGameRecordReader = new BowlingGameRecordReader();	
	}
	
	@Test
	public void givenAnEmptyGameRecordsAreProvidedWhenTheyAreReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add("");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});

		Assertions.assertEquals(
				"A format error was found on line \"\", line number = 1, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenAGameRecordStartsWithEmptySpaceWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add(" Player\t1");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});

		Assertions.assertEquals(
				"A format error was found on line \" Player\t1\", line number = 1, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenAGameRecordEndsWithEmptySpaceWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add("Player\t1 ");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});

		Assertions.assertEquals(
				"A format error was found on line \"Player\t1 \", line number = 1, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenAGameRecordWithExtrasColumnsWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(2);
		gameRecords.add("Player\t1");
		gameRecords.add("Player2\t1\t2");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});

		Assertions.assertEquals(
				"A format error was found on line \"Player2\t1\t2\", line number = 2, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenAGameRecordWithInvalidKnockedDownPinsWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add("Player\tf");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});

		Assertions.assertEquals(
				"A format error was found on line \"Player\tf\", line number = 1, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenAGameRecordWithInvalidNumberOfKnockedDownPinsWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add("Player\t11");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});
		Assertions.assertEquals(
				"A format error was found on line \"Player\t11\", line number = 1, the number of knocked down pins could be 0,1,2,3,4,5,6,8,9,10 and letter 'F' in case a fault occurred.",
				gameRecordFormatException.getMessage());
	}
	
	@Test
	public void givenAGameRecordWithDoubleTabIsProvidedWhenItIsReadThenThrowGameRecordFormatException() {
		final List<String> gameRecords = new ArrayList<String>(1);
		gameRecords.add("Player\t\t5");

		final GameRecordFormatException gameRecordFormatException = Assertions
				.assertThrows(GameRecordFormatException.class, () -> {
					bowlingGameRecordReader.readGameRecord(gameRecords);
				});
		Assertions.assertEquals(
				"A format error was found on line \"Player\t\t5\", line number = 1, make sure the line starts and ends without blank spaces and follows format:${player}\\tab${knocked_down_pins}.",
				gameRecordFormatException.getMessage());
	}

	@Test
	public void givenValidGameRecordsAreProvidedWhenTheyAreReadThenReturnAListOfBasicBowlingGameRecord()
			throws GameRecordFormatException {
		final List<String> gameRecords = new ArrayList<String>(2);
		gameRecords.add("Player1	5");
		gameRecords.add("Player2	F");
		gameRecords.add("Player3	0");
		gameRecords.add("Player4	10");

		final List<BasicBowlingGameRecord> basicBowlingGameRecords = bowlingGameRecordReader
				.readGameRecord(gameRecords);

		Assertions.assertEquals(4, basicBowlingGameRecords.size());
		validateBasicBowlingGameRecord(basicBowlingGameRecords.get(0), "Player1", "5");
		validateBasicBowlingGameRecord(basicBowlingGameRecords.get(1), "Player2", "F");
		validateBasicBowlingGameRecord(basicBowlingGameRecords.get(2), "Player3", "0");
		validateBasicBowlingGameRecord(basicBowlingGameRecords.get(3), "Player4", "10");
	}

	private void validateBasicBowlingGameRecord(BasicBowlingGameRecord basicBowlingGameRecord, String playerName,
			String pinsKnockedDown) {
		Assertions.assertEquals(playerName, basicBowlingGameRecord.getPlayer());
		Assertions.assertEquals(pinsKnockedDown, basicBowlingGameRecord.getPinsKnockedDown());
	}
}
