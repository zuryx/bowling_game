package com.foo.game.domain.bowling;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BasicBowlingGameRecordGameAdapterTest {
	
	private BasicBowlingGameRecordGameAdapter basicBowlingGameRecordGameAdapter;
	
	@BeforeEach
	public void beforeTest() {
		basicBowlingGameRecordGameAdapter = new BasicBowlingGameRecordGameAdapter();	
	}
	
	@Test
	public void whenStrikeGameRecordIsAdaptedThenReturnStrikeGameAction() {
		BasicBowlingGameRecord basicBowlingGameRecord = new BasicBowlingGameRecord("PlayerA", "10");
		
		BowlingPlayerGameAction playerGameAction = basicBowlingGameRecordGameAdapter.adapt(basicBowlingGameRecord);
		
		Assertions.assertEquals("PlayerA",playerGameAction.getPlayer().getPlayerName());
		Assertions.assertTrue(playerGameAction.getGameAction() instanceof Strike);
	}
	
	@Test
	public void whenFaultGameRecordIsAdaptedThenReturnStrikeGameAction() {
		BasicBowlingGameRecord basicBowlingGameRecord = new BasicBowlingGameRecord("PlayerA", "F");
		
		BowlingPlayerGameAction playerGameAction = basicBowlingGameRecordGameAdapter.adapt(basicBowlingGameRecord);
		
		Assertions.assertEquals("PlayerA",playerGameAction.getPlayer().getPlayerName());
		Assertions.assertTrue(playerGameAction.getGameAction() instanceof Foul);
	}
	
	@Test
	public void whenNormalGameRecordIsAdaptedThenReturnStrikeGameAction() {
		BasicBowlingGameRecord basicBowlingGameRecord = new BasicBowlingGameRecord("PlayerA", "1");
		
		BowlingPlayerGameAction playerGameAction = basicBowlingGameRecordGameAdapter.adapt(basicBowlingGameRecord);
		
		Assertions.assertEquals("PlayerA",playerGameAction.getPlayer().getPlayerName());
		Assertions.assertTrue(playerGameAction.getGameAction() instanceof RegularShot);
	}
}
