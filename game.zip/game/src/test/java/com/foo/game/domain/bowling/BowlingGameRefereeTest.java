package com.foo.game.domain.bowling;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.foo.game.domain.GameException;
import com.foo.game.domain.Player;

public class BowlingGameRefereeTest {
	
	private BowlingGameScore bowlingGameScore; 	
	private BowlingGameReferee bowlingGameReferee;
	
	@BeforeEach
	public void beforeTest() {
		bowlingGameScore = Mockito.mock(BowlingGameScore.class);		
		bowlingGameReferee = new BowlingGameReferee(bowlingGameScore);
	}
	
	//TODO: AGREGAR EL TEST DE USUARIOS QUE QUIERAN TIRAR SI NO ESTAN DADOS DE ALTA
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemMadeAStrikeAndKeepPlayingInTheFirstNineFramesThenThrowGameException() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		BowlingPlayerGameAction bowlingPlayerGameAction = new BowlingPlayerGameAction(bowlingPlayer, new Strike());
		BowlingPlayerGameAction bowlingPlayerGameAction2 = new BowlingPlayerGameAction(bowlingPlayer, new Strike());
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(bowlingPlayerGameAction);
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(bowlingPlayerGameAction2);
		});		
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemMadeAStrikeThenHisFrameEndsAndNoExceptionIsThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		BowlingPlayerGameAction bowlingPlayerGameAction = new BowlingPlayerGameAction(bowlingPlayer, new Strike());
		BowlingPlayerGameAction bowlingPlayerGameAction2 = new BowlingPlayerGameAction(bowlingPlayerB, new Strike());
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(bowlingPlayerGameAction);
		bowlingGameReferee.checkGamePlay(bowlingPlayerGameAction2);		
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenBothOfThemMadeAStrikeThenFistPlayerPlayAgainAndNoExceptionIsThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemOnlyKnockedDownSomeThenPlayAgainAndNoExceptionIsThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(5)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(4)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemDoAFoulThenPlayAgainAndNoExceptionIsThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemDoesMoreThanTwoFoulsThenAGameException() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		});
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenOneOfThemShotMoreThanTwoTimesThenAGameException() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		});
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Strike()));
	}
	
	@Test
	public void givenTwoPlayersArePlayingWhenBothPlayerFinishAFrameThenANewFrameShouldBeCreated() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		Player<BowlingGameAction> bowlingPlayerB = new BowlingPlayer("PlayerB");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		players.add(bowlingPlayerB);
		
		bowlingGameReferee.addPlayers(players);
		Frame frameOne = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(5)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayerB, new RegularShot(5)));
		Frame frameTwo = bowlingGameReferee.getCurrentFrame();
		
		Assertions.assertEquals(1,frameOne.getFrameNumber());
		Assertions.assertEquals(2,frameTwo.getFrameNumber());
	}
	
	@Test
	public void givenOnePlayerIsPlayingWhenFinishAFrameThenANewFrameShouldBeCreated() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");		
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		
		bowlingGameReferee.addPlayers(players);
		Frame frameOne = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(5)));
		Frame frameTwo = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		Frame frameThree = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(4)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		Frame frameFour = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Frame frameFive = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(4)));
		Frame frameSix = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Frame frameSeven = bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Frame frameEight= bowlingGameReferee.getCurrentFrame();
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Frame frameNine = bowlingGameReferee.getCurrentFrame();
		
		Assertions.assertEquals(1,frameOne.getFrameNumber());
		Assertions.assertEquals(2,frameTwo.getFrameNumber());
		Assertions.assertEquals(3,frameThree.getFrameNumber());
		Assertions.assertEquals(4,frameFour.getFrameNumber());
		Assertions.assertEquals(5,frameFive.getFrameNumber());
		Assertions.assertEquals(6,frameSix.getFrameNumber());
		Assertions.assertEquals(7,frameSeven.getFrameNumber());
		Assertions.assertEquals(8,frameEight.getFrameNumber());
		Assertions.assertEquals(9,frameNine.getFrameNumber());
	}
	
	@Test
	public void whenTheSumOfTheKnockedPinsBetweenRegularShotIsGreaterThanTenAGameExceptionShouldBeThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");		
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		Frame frame = new Frame();
		frame.setFrameNumber(1);
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(3)));
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(9)));
		});
		
	}
	
	@Test
	public void whenTheSumOfTheKnockedPinsBetweenARegularShotAndAStrikeIsGreaterThanTenAGameExceptionShouldBeThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");		
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);
		Frame frame = new Frame();
		frame.setFrameNumber(1);
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(1)));
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		});
	}
	
	@Test
	public void whenPlayerKeepPlayingAfterFinishThenThenGameExceptionIsThrown() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);		
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		Assertions.assertTrue(bowlingGameReferee.isGameFinish());
		
		Assertions.assertThrows(GameException.class, () -> {
			bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		});
	}
	
	@Test
	public void whenLastShotIsAStrikeThenTwoExtraShotsAreAllowed() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);		
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertFalse(bowlingGameReferee.isGameFinish());
		//Extra
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertFalse(bowlingGameReferee.isGameFinish());
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertTrue(bowlingGameReferee.isGameFinish());
	}
	
	@Test
	public void whenLastShotIsASpareWithAStrikeThenOneExtraShotIsAllowed() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);		
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Foul()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertFalse(bowlingGameReferee.isGameFinish());
		//Extra
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertTrue(bowlingGameReferee.isGameFinish());		
	}
	
	@Test
	public void whenLastShotIsASpareWithRegularShotsThenOneExtraShotIsAllowed() throws GameException {
		Player<BowlingGameAction> bowlingPlayer = new BowlingPlayer("PlayerA");
		List<Player<BowlingGameAction> > players = new ArrayList<>();
		players.add(bowlingPlayer);		
		
		bowlingGameReferee.addPlayers(players);		
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(6)));
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new RegularShot(4)));
		Assertions.assertFalse(bowlingGameReferee.isGameFinish());
		//Extra
		bowlingGameReferee.checkGamePlay(new BowlingPlayerGameAction(bowlingPlayer, new Strike()));
		Assertions.assertTrue(bowlingGameReferee.isGameFinish());		
	}
}
