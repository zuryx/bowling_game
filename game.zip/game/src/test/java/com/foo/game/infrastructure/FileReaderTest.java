package com.foo.game.infrastructure;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.internal.verification.VerificationModeFactory;


public class FileReaderTest {

	private FileValidator fileValidatorMock;	
	private FileReader fileReader;

	@BeforeEach
	public void beoreTest() {
		fileReader = new FileReader();
		fileValidatorMock = Mockito.mock(FileValidator.class);
	}
	@Test
	public void givenAnEmptyFileProvidedWhenFileIsReadThenReturnEmptyList() throws InvalidFileException {
		final Path filePath = Paths.get("src", "test", "resources", "file_reader", "game_record.txt");
		Mockito.doNothing().when(fileValidatorMock).validateFile(filePath);

		final List<String> lines = fileReader.readFile(filePath, fileValidatorMock);

		Mockito.verify(fileValidatorMock, VerificationModeFactory.only()).validateFile(filePath);
		Assertions.assertEquals(2, lines.size());
	}

	@Test
	public void whenAnIOExceptionOccursAfterFileValidatorSuccessThenThrowInvalidFileException()
			throws InvalidFileException {
		final Path filePath = Paths.get("src", "test", "resources", "file_reader", "force_exception_file.txt");
		Mockito.doNothing().when(fileValidatorMock).validateFile(filePath);

		final InvalidFileException invalidFileException = Assertions.assertThrows(InvalidFileException.class, () -> {
			fileReader.readFile(filePath, fileValidatorMock);
		});

		Mockito.verify(fileValidatorMock, VerificationModeFactory.only()).validateFile(filePath);
		Assertions.assertEquals(
				"An error occurred while reading file \"src" + File.separator + "test" + File.separator + "resources"
						+ File.separator + "file_reader" + File.separator
						+ "force_exception_file.txt\" please try again, if the error persist please contact support.",
				invalidFileException.getMessage());
	}
}
